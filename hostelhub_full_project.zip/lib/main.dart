import 'package:flutter/material.dart';
import 'screens/main_screen.dart';

void main() {
  runApp(HostelHubApp());
}

class HostelHubApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'HostelHub',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: MainScreen(),
    );
  }
}
