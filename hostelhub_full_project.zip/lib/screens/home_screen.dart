import 'package:flutter/material.dart';
import '../widgets/item_card.dart';

class HomeScreen extends StatelessWidget {
  final items = [
    {"name": "Calculator", "price": "₹300"},
    {"name": "Lamp", "price": "₹150"},
    {"name": "Cycle (Rent)", "price": "₹50/day"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("HostelHub")),
      body: ListView.builder(
        itemCount: items.length,
        itemBuilder: (context, index) {
          return ItemCard(
            name: items[index]["name"],
            price: items[index]["price"],
          );
        },
      ),
    );
  }
}
