import 'package:flutter/material.dart';

class ItemCard extends StatelessWidget {
  final String name;
  final String price;

  ItemCard({required this.name, required this.price});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(10),
      child: ListTile(
        title: Text(name),
        subtitle: Text(price),
        trailing: Icon(Icons.arrow_forward),
      ),
    );
  }
}
